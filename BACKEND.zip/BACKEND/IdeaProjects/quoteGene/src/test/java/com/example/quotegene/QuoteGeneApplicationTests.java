package com.example.quotegene;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuoteGeneApplicationTests {

    @Test
    void contextLoads() {
    }

}
